export const AUTH_CONFIG = {
  domain: 'team-eight.auth0.com',
  clientId: '7-SLYgZhE9WxIGd6l9DFGxJ-DexQQm1n',
  callbackUrl: 'http://localhost:3000/callback'
}
